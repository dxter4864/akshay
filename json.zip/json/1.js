
let obj = {
    id: 1,
    price: 99.99,
    str: "akki",
};


console.log(obj);